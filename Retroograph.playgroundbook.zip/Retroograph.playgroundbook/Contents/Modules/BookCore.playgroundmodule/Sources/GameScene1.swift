import SpriteKit
import Foundation
import PlaygroundSupport
import AVFoundation

public var finalCollage: SKSpriteNode!

public class GameScene1: SKScene {
    
    var state: State{
        if sceneNode1.parent != nil && sceneNode1.childNode(withName: "background") != nil{
            return.escolherFoto
        }
        if sceneNode1.parent != nil && sceneNode1.childNode(withName: "backgroundChange") != nil{
            return.tirarFotodaFoto
        }
        if sceneNode2.parent != nil{
            return.polaroid
        }
        if sceneNode3.parent != nil{
            return.colagem
        }
        return.colagem // tanto faz o retorno
    }
    
    var sceneNode1 = SKNode()
    var sceneNode2 = SKNode()
    var sceneNode3 = SKNode()
    var sceneNode4 = SKNode()
    
    var phrase1Scene1: SKLabelNode!
    var phrase2Scene1: SKLabelNode!
    var phrase3Scene1: SKLabelNode!
    var phrase1Scene2: SKLabelNode!
    var phrase2Scene2: SKLabelNode!
    var phrase3Scene2: SKLabelNode!
    var phrase4Scene2: SKLabelNode!
    var phrase1Scene3: SKLabelNode!
    var phrase2Scene3: SKLabelNode!
    var buttonFinish:  SKLabelNode!
    var buttonReturn:  SKLabelNode!
    var buttonNext:  SKLabelNode!
    
    var photo: SKSpriteNode!
    
    var music: AVAudioPlayer!
    
    var moveObjets: SKSpriteNode!
    var objects = [SKSpriteNode]()
    var polaroids = [SKSpriteNode]()
    var background = SKSpriteNode(imageNamed: "desk")
    let backgroundChange = SKSpriteNode(imageNamed:"deskWithoutLight")
    let lightBackground = SKSpriteNode(imageNamed:"deskLight")
    var photoSelect: SKSpriteNode!
    var pictures = [SKSpriteNode]()
    var cameraPhoto = SKSpriteNode(imageNamed: "polaroid")
    var cliked: SKSpriteNode!
    var dragging: SKSpriteNode!
    let rectangle = SKSpriteNode(imageNamed: "backgroundCollage")
    var countPhotos = 0
    var countMovesObjects = 0;
    var button = SKShapeNode(rectOf: CGSize(width: 100, height: 100))
    var verifiButton = false
    var verifiCollage = false
    let button2 = SKLabelNode(text: "finish")
    
    var phraseSequence: SKAction!
    
    //let wait1 = SKAction.wait(forDuration: 1) // Tempo inicial até o balão aparecer
    var wait = SKAction.wait(forDuration: 6)
    var fadeIn = SKAction.fadeIn(withDuration: 0.4)
    var wait2 = SKAction.wait(forDuration: 4)
    var fadeOut = SKAction.fadeOut(withDuration: 0.4)
    
    var secundTime = false
    
    var waitTalk: SKAction!
    
    var zPositionTop = CGFloat(100)
    
    override public func didMove(to view: SKView) {
        // Get label node from scene and store it for use later
        //label = childNode(withName: "//helloLabel") as? SKLabelNode
        addChild(sceneNode1)
       
        GSAudio.sharedInstance.playSound (soundFileName: "music", loops: true, volume: 0.025)
        
        sceneNode1.name = "scene 1"
        sceneNode2.name = "scene 2"
        sceneNode3.name = "scene 3"
        sceneNode4.name = "scene 4"
        
        phrase1Scene1 = childNode(withName: "//phrase1Scene2") as? SKLabelNode
        phrase2Scene1 = childNode(withName: "//phrase2Scene2") as? SKLabelNode
        phrase3Scene1 = childNode(withName: "//phrase3Scene2") as? SKLabelNode
        phrase1Scene2 = childNode(withName: "//phrase1Scene3") as? SKLabelNode
        phrase2Scene2 = childNode(withName: "//phrase2Scene3") as? SKLabelNode
        phrase3Scene2 = childNode(withName: "//phrase3Scene3") as? SKLabelNode
        phrase4Scene2 = childNode(withName: "//phrase4Scene3") as? SKLabelNode
        phrase1Scene3 = childNode(withName: "//phrase1Scene4") as? SKLabelNode
        phrase2Scene3 = childNode(withName: "//phrase2Scene4") as? SKLabelNode
        buttonFinish = childNode(withName: "//buttonFinish") as? SKLabelNode
        buttonReturn = childNode(withName: "//buttonReturn") as? SKLabelNode
        buttonNext   = childNode(withName: "//buttonNext") as? SKLabelNode
        
        photo = childNode(withName: "//photo") as? SKSpriteNode
        
        setup()
    }
    
    func setup (){
        background = SKSpriteNode(imageNamed: "desk1")
        background.position = CGPoint(x: 0, y:0)
        background.name = "background"
        sceneNode1.addChild(background)
    
        pictures = []
        
        for i in 1 ... 10 {
            // Nome da imagem a partir do índice
            let name = "P\(i)"
            let picture = SKSpriteNode(imageNamed: name)
            picture.zPosition = 2
            picture.name = name
            pictures.append(picture)
            picture.setScale(0.20)
            
        
        }
        //Acrescenta as imagens em determinada posicao no album
        pictures[0].position = CGPoint(x: 150, y: 270)
        pictures[0].zRotation = 11
        
        pictures[1].position = CGPoint(x: -40, y: 285)
        pictures[1].zRotation = -13
        
        pictures[2].position = CGPoint(x: -169, y: 107)
        pictures[3].position = CGPoint(x: 86, y: 34)
        
        pictures[4].position = CGPoint(x: 269, y: 107)
        pictures[4].zRotation = -14
        
        pictures[5].position = CGPoint(x: -154, y: -48)
        pictures[5].zRotation = -10
        
        pictures[6].position = CGPoint(x: 5, y: -24)
        pictures[7].position = CGPoint(x: 302, y: -80)
        
        pictures[8].position = CGPoint(x: 209, y: -189)
        pictures[8].zRotation = 11
        
        pictures[9].position = CGPoint(x: -16, y: -203)
        pictures[9].zRotation = 22
        
        lightBackground.zPosition = 5
        lightBackground.alpha = 0.5
        lightBackground.position = CGPoint(x: 0, y: 0)
        sceneNode1.addChild(lightBackground)
        
        for picture in pictures{
            sceneNode1.addChild(picture)
        }
        
        if secundTime == false{
            waitTalk = SKAction.wait(forDuration: 2)
            run(waitTalk) {
                GSAudio.sharedInstance.playSound(soundFileName: "talk6", loops: false, volume: 0.6)
            }
            phrase1Scene1.zPosition = 3
            phraseSequence = SKAction.sequence([waitTalk, fadeIn, wait2, fadeOut])
            phrase1Scene1.run(phraseSequence)
            
            phrase2Scene1.zPosition = 3
            phraseSequence = SKAction.sequence([ wait, fadeIn, wait2, fadeOut])
            phrase2Scene1.run(phraseSequence)
        
        }

    }
    
    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }
  
//  PHOTO
    
    func touchDownPhoto(atPoint pos : CGPoint) {
        guard state == .escolherFoto else {
            return
        }
        for _ in pictures{
            if let picture = pictures.reversed().first(where: { picture in picture.contains(pos) }) {
                cliked = picture
                photoSelect = picture
                
                break
            }
        }
    }
    
    func touchUpPhoto(atPoint pos : CGPoint) {
        guard state == .escolherFoto else {
            return
        }
        if cliked != nil {
            phrase3Scene1.zPosition = 4
            phraseSequence = SKAction.sequence([fadeIn, wait2, fadeOut])
            phrase3Scene1.run(phraseSequence)
            
            cliked.setScale(0.7)
            cliked.zRotation = 0
            cliked.position = CGPoint(x: 0, y: 0)
            cliked.zPosition = 3
            sceneNode1.removeAllChildren()
            sceneNode1.addChild(cliked)
            
        
            backgroundChange.zPosition = 2
            backgroundChange.position = CGPoint(x: 0, y: 0)
            backgroundChange.name = "backgroundChange"
            sceneNode1.addChild(backgroundChange)
            
            lightBackground.zPosition = 4
            sceneNode1.addChild(lightBackground)
            
            
            cameraPhoto = SKSpriteNode(imageNamed: "polaroid")
            cameraPhoto.setScale(0.9)
            cameraPhoto.position = CGPoint(x: -518, y: -389)
            cameraPhoto.zPosition = 3
            sceneNode1.addChild(cameraPhoto)
            
            cliked = nil
            
        }
    }
    
// CAMERA

    func touchDownCamera(atPoint pos : CGPoint) {
        guard state == .tirarFotodaFoto else {
            return
        }
        if cameraPhoto.contains(pos) {
            dragging = cameraPhoto
            return
        }
        
    }
    
    func touchMovedCamera(toPoint pos : CGPoint) {
       
        guard state == .tirarFotodaFoto else {
            return
        }
        if dragging != nil {
            if cliked == nil {
                let changePositionPolaroid = SKAction.setTexture(SKTexture(imageNamed: "changePositionPolaroid"))
                cameraPhoto.setScale(1.1)
                cameraPhoto.zPosition = 4
                cameraPhoto.position = pos
                cameraPhoto.run(changePositionPolaroid)
            }
        }
    }

    //funcao para cortar a imagem selecionada
    func touchUpCamera(atPoint pos : CGPoint){
        guard state == .tirarFotodaFoto else {
            return
        }
        if dragging != nil {
            if !photoSelect.contains(pos){
                return
            }
            sceneNode1.removeAllChildren()
            sceneNode1.removeFromParent()
            addChild(sceneNode2)
            
            GSAudio.sharedInstance.playSound(soundFileName: "clickCamera", loops: false, volume: 0.06)
            
            let rectangle = SKSpriteNode(color: .red, size: CGSize(width: photoSelect.size.width - 200, height: photoSelect.size.height - 320))
            rectangle.position = .zero
            rectangle.zPosition = 10
            //photoSelect.addChild(rectangle)
            sceneNode2.addChild(rectangle)
//
            let cameraRect = SKSpriteNode(color: .black, size: CGSize(width:200,height:200))
            var position = pos

            if !rectangle.contains(pos){
                if pos.x < rectangle.frame.minX{
                    position.x = rectangle.frame.minX
                }
                if pos.x > rectangle.frame.maxX{
                    position.x = rectangle.frame.maxX
                }
                if pos.y < rectangle.frame.minY{
                    position.y = rectangle.frame.minY
                }
                if pos.y > rectangle.frame.maxY{
                    position.y = rectangle.frame.maxY
                }
            }
            rectangle.removeFromParent()
            
            cameraRect.position = CGPoint (x: position.x - photoSelect.position.x, y: position.y - photoSelect.position.y)
            cameraRect.zPosition = CGFloat(3 + countPhotos * 3)
            let picture = SKCropNode()
            picture.maskNode = cameraRect
            picture.addChild(photoSelect)
            
            sceneNode2.addChild(backgroundChange)
            lightBackground.zPosition = 4
            sceneNode2.addChild(lightBackground)
            
            let polaroidFormat = SKSpriteNode(imageNamed:"polaroidFormat.png")
            polaroidFormat.position = CGPoint(x: 0, y: 0)
            let dX = (position.x - photoSelect.position.x)*3.2
            let dY = (position.y - photoSelect.position.y)*3.2
            picture.position = CGPoint(x: -dX - 2, y: -dY + 71)
            
            polaroidFormat.zPosition = CGFloat(3 + countPhotos * 3)
            picture.zPosition = CGFloat(3 + countPhotos * 3)
            picture.setScale(3.2)
            polaroidFormat.addChild(picture)
            polaroidFormat.setScale(0.7)
            polaroids.append(polaroidFormat)
            sceneNode2.addChild(polaroidFormat)
            dragging = nil
            
            countPhotos += 1
            
            if countPhotos < maxPhotosCount {
                verifiButton = true
                
                waitTalk = SKAction.wait(forDuration: 1.5)
                run(waitTalk) {
                    GSAudio.sharedInstance.playSound(soundFileName: "talk7", loops: false, volume: 0.6)
                }
                phrase1Scene2.zPosition = 3
                phraseSequence = SKAction.sequence([waitTalk,fadeIn, wait2,.wait(forDuration: 2) ,fadeOut])
                phrase1Scene2.run(phraseSequence)
              
     
                phrase2Scene2.zPosition = 4
                phraseSequence = SKAction.sequence([.wait(forDuration: 8.5), fadeIn, .wait(forDuration: 4), fadeOut])
                phrase2Scene2.run(phraseSequence)
                
                let buttonSequence = SKAction.sequence([.wait(forDuration: 8.5), fadeIn])
                buttonReturn.zPosition = 4
                buttonReturn.run(buttonSequence)
                secundTime = true
        
                
            }else{
                verifiButton = true
                waitTalk = SKAction.wait(forDuration: 1.5)
                run(waitTalk) {
                    GSAudio.sharedInstance.playSound(soundFileName: "talk9", loops: false, volume: 0.6)
                }
                phrase3Scene2.zPosition = 4
                phraseSequence = SKAction.sequence([waitTalk, fadeIn, wait2,.wait(forDuration: 1), fadeOut])
                phrase3Scene2.run(phraseSequence)
         
                waitTalk = SKAction.wait(forDuration: 8)
                run(waitTalk) {
                    GSAudio.sharedInstance.playSound(soundFileName: "talk8", loops: false, volume: 0.6)
                }
                phrase4Scene2.zPosition = 10
                phraseSequence = SKAction.sequence([ waitTalk, fadeIn, wait2, .wait(forDuration: 2), .fadeOut(withDuration: 0.2)])
                phrase4Scene2.run(phraseSequence)
                
                let buttonSequence = SKAction.sequence([waitTalk,fadeIn])
                buttonNext.zPosition = 10
                buttonNext.run(buttonSequence)
            }
        }
    }
    
    let maxPhotosCount = 2
    func touchDownButton(atPoint pos : CGPoint ){
        guard state == .polaroid else {
            return
        }
        if verifiButton != false{
            phrase4Scene2.run(.fadeOut(withDuration: 0.2))
            if  buttonNext.contains(pos) {
                sceneNode2.removeFromParent()
                sceneNode2.removeAllChildren()
                if countPhotos >= maxPhotosCount {
                    addChild(sceneNode3)
                    for polaroid in polaroids{
                        polaroid.removeFromParent()
                    }
                    verifiButton = false
                    buttonNext.alpha = 0
                    createCollage()

                }else{
                    if sceneNode1.parent == nil {
                        addChild(sceneNode1)
                        buttonReturn.alpha = 0
                        verifiButton = false
                        setup()
                    }
                }
            }
        }
    }
    
    
    func createCollage(){
        //if dragging == nil{
        //adicionar background da mesa
        backgroundChange.alpha = 1
        backgroundChange.isHidden = false
        sceneNode3.addChild(backgroundChange)
        lightBackground.zPosition = 20
        sceneNode3.addChild(lightBackground)

        rectangle.zPosition = 2
        rectangle.position = CGPoint(x: 0, y: 0)
        sceneNode3.addChild(rectangle)
        
        var positionP = 320
        for polaroid in polaroids{
            //polaroid.zPosition = 3
            polaroid.position = CGPoint(x: 400,y: positionP)
            polaroid.setScale(0.4)
            objects.append(polaroid)
            rectangle.addChild(polaroid)
            positionP = -220
        }
        
        for i in 1 ... 12 {
            // Nome da imagem a partir do índice
            let name = "obj\(i)"
            let object = SKSpriteNode(imageNamed: name)
            objects.append(object)
            object.zPosition = 15
            object.setScale(0.4)
            object.position = CGPoint(x: Int.random(in: -500 ... -380), y: Int.random(in: -300 ... -200))
            rectangle.addChild(object)
        }
        
        for i in 14 ... 20 {
            // Nome da imagem a partir do índice
            let name = "obj\(i)"
            let object = SKSpriteNode(imageNamed: name)
            objects.append(object)
            object.zPosition =  13
            object.setScale(0.6)
            object.position = CGPoint(x: Int.random(in: -620 ... -420), y: Int.random(in: -180...180))
            rectangle.addChild(object)
        }
        
        phrase1Scene3.zPosition = 3
        phraseSequence = SKAction.sequence([ fadeIn, wait2, fadeOut])
        phrase1Scene3.run(phraseSequence)
        
        verifiCollage = true
    }
    
// OBJECTS
    
    func touchDownObjects(atPoint pos : CGPoint ){
        guard state == .colagem else {
            return
        }
        if verifiCollage != false{
            for object in objects {
                if let object = objects.reversed().first(where: { object in object.contains(pos) }) {
                //if object.contains(pos) {
                    object.zPosition = zPositionTop
                    zPositionTop += 20
                    let width = object.size.width
                    let height = object.size.height
                    if pos.x < object.position.x + width / 2 &&
                        pos.x > object.position.x - width / 2 &&
                        pos.y < object.position.y + height / 2 &&
                        pos.y > object.position.y - height / 2 {
                        moveObjets = object
                        countMovesObjects += 1
                        return
                   }
                }
            }
        }
        
    }

    func touchMovedObjects(toPoint pos : CGPoint) {
        guard state == .colagem else {
            return
        }
        if moveObjets != nil {
            moveObjets.position = pos
        }

    }
    
    func touchUpObjects(atPoint pos : CGPoint) {
        guard state == .colagem else {
            return
        }
        if moveObjets != nil {
            if countMovesObjects == 7{
                waitTalk = SKAction.wait(forDuration: 2)
                run(waitTalk) {
                    GSAudio.sharedInstance.playSound(soundFileName: "talk11", loops: false, volume: 0.6)
                }
                phrase2Scene3.zPosition = 3
                phraseSequence = SKAction.sequence([waitTalk, fadeIn, wait2, .wait(forDuration: 1), fadeOut])
                phrase2Scene3.run(phraseSequence)
                
                buttonFinish.zPosition = 6
                let buttonSequence = SKAction.sequence([waitTalk, fadeIn])
                buttonFinish.run(buttonSequence)
 
            }
            moveObjets = nil
        }
    }
    
// COLLAGE
    
    func touchDownButtonCollage(atPoint pos : CGPoint ){
        guard state == .colagem else {
            return
        }
        if buttonFinish.contains(pos) && buttonFinish.alpha == 1{
            rectangle.removeFromParent()
            rectangle.setScale(1)
            let cameraRect = SKSpriteNode(color: .black, size: CGSize(width:640,height:640))
            let collage = SKCropNode()
            collage.maskNode = cameraRect
            collage.addChild(rectangle)
            finalCollage = SKSpriteNode(imageNamed: "finalCollage")
            finalCollage.position = CGPoint(x: 0, y: 0)
            finalCollage.addChild(collage)
            let gameScene = GameScene2(fileNamed: "GameScene2")
            gameScene?.size = CGSize(width: 1366, height: 1024)
            gameScene?.scaleMode = .aspectFill
            self.view?.presentScene(gameScene)
            
        }
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchDownPhoto(atPoint: t.location(in: self)) }
        for c in touches { self.touchDownCamera(atPoint: c.location(in: self)) }
        for o in touches { self.touchDownObjects(atPoint: o.location(in: self)) }
        for b in touches { self.touchDownButton(atPoint: b.location(in: self)) }
        for l in touches { self.touchDownButtonCollage(atPoint: l.location(in: self)) }
        
    }

    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchMovedCamera(toPoint: t.location(in: self)) }
        for o in touches { self.touchMovedObjects(toPoint: o.location(in: self))}
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for m in touches {self.touchUpCamera(atPoint: m.location(in: self))}
        for o in touches {self.touchUpObjects(atPoint: o.location(in: self))}
        for t in touches {self.touchUpPhoto(atPoint: t.location(in: self)) }
    }
    
}

enum State{
    case escolherFoto
    case tirarFotodaFoto
    case polaroid
    case colagem
}
