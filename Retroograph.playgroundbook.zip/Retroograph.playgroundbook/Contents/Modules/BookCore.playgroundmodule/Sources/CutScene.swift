import SpriteKit
import Foundation
import PlaygroundSupport
import AVFoundation

public class CutScene: SKScene {
    

    var phrase0: SKLabelNode!
    var phrase1: SKLabelNode!
    var phrase2: SKLabelNode!
    var phrase3: SKLabelNode!
    var phrase4: SKLabelNode!
    var phrase5: SKLabelNode!
    var phrase6: SKLabelNode!
    var phrase7: SKLabelNode!
    var phrase12: SKLabelNode!
    
    var background1: SKSpriteNode!
    var background2: SKSpriteNode!
    var background3: SKSpriteNode!
    var background4: SKSpriteNode!
    var background5: SKSpriteNode!
    
    var backgroundSequence: SKAction!
    var phraseSequence: SKAction!
    
    var music : AVAudioPlayer!
    var audio: SKAudioNode!
    
    override public func didMove(to view: SKView) {
        // Get label node from scene and store it for use later
        
        phrase0 = childNode(withName: "//phrase0") as? SKLabelNode
        phrase1 = childNode(withName: "//phrase1") as? SKLabelNode
        phrase2 = childNode(withName: "//phrase2") as? SKLabelNode
        phrase3 = childNode(withName: "//phrase3") as? SKLabelNode
        phrase4 = childNode(withName: "//phrase4") as? SKLabelNode
        phrase5 = childNode(withName: "//phrase5") as? SKLabelNode
        phrase6 = childNode(withName: "//phrase6") as? SKLabelNode
        phrase7 = childNode(withName: "//phrase7") as? SKLabelNode
        phrase12 = childNode(withName: "//phrase12") as? SKLabelNode
        
        background1 = childNode(withName: "//background1") as? SKSpriteNode
        background2 = childNode(withName: "//background2") as? SKSpriteNode
        background3 = childNode(withName: "//background3") as? SKSpriteNode
        background4 = childNode(withName: "//background4") as? SKSpriteNode
        background5 = childNode(withName: "//background5") as? SKSpriteNode
        

        GSAudio.sharedInstance.playSound (soundFileName: "rainMusic3", loops: false, volume: 0.8)
        
        var phraseWait: SKAction!
        let fadeIn = SKAction.fadeIn(withDuration: 0.5)
        let fadeOut = SKAction.fadeOut(withDuration: 0.5)
       
        let backgroundFadeIn = SKAction.fadeIn(withDuration: 1)
        let backgroundFadeOut = SKAction.fadeOut(withDuration: 1)
    

        backgroundSequence = SKAction.sequence([backgroundFadeIn,.wait(forDuration: 14), backgroundFadeOut])
        background1.run(backgroundSequence)
        
        phrase0.zPosition = 2
        phraseSequence = SKAction.sequence([fadeIn, .wait(forDuration: 4), fadeOut])
        phrase0.run(phraseSequence)
        
        
        phrase1.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 5)
        phraseSequence = SKAction.sequence([.wait(forDuration: 5), fadeIn, .wait(forDuration: 4), fadeOut])
        phrase1.run(phraseSequence)
        
        phrase12.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 10)
        phraseSequence = SKAction.sequence([.wait(forDuration: 11), fadeIn, .wait(forDuration: 4), fadeOut])
        phrase12.run(phraseSequence)
        
    
        backgroundSequence = SKAction.sequence([.wait(forDuration: 15), backgroundFadeIn,.wait(forDuration: 12), backgroundFadeOut])
        background2.run(backgroundSequence)

        phrase2.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 17)
        phraseSequence = SKAction.sequence([.wait(forDuration: 17), fadeIn,.wait(forDuration: 5), fadeOut])
        phrase2.run(phraseSequence)

        phrase3.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 23)
        phraseSequence = SKAction.sequence([.wait(forDuration: 23), fadeIn,.wait(forDuration: 4), fadeOut])
        phrase3.run(phraseSequence)
        run(phraseWait) {
            GSAudio.sharedInstance.playSound (soundFileName: "talk1", loops: false, volume: 0.6)
        }


        backgroundSequence = SKAction.sequence([.wait(forDuration: 28), backgroundFadeIn,.wait(forDuration: 15), backgroundFadeOut])
        background3.run(backgroundSequence)

        phrase4.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 30)
        phraseSequence = SKAction.sequence([.wait(forDuration: 30), fadeIn,.wait(forDuration: 6.5), fadeOut])
        phrase4.run(phraseSequence)
        run(phraseWait) {
            GSAudio.sharedInstance.playSound (soundFileName: "talk2", loops: false, volume: 0.6)
        }

        phrase5.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 39)
        phraseSequence = SKAction.sequence([.wait(forDuration: 39), fadeIn,.wait(forDuration: 4), fadeOut])
        phrase5.run(phraseSequence)
        run(phraseWait) {
            GSAudio.sharedInstance.playSound (soundFileName: "talk3", loops: false, volume: 0.6)
        }

        backgroundSequence = SKAction.sequence([.wait(forDuration: 44), backgroundFadeIn,.wait(forDuration: 7), backgroundFadeOut])
        background4.run(backgroundSequence)


        phrase6.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 44)
        phraseSequence = SKAction.sequence([.wait(forDuration: 44), fadeIn,.wait(forDuration: 6.5), fadeOut])
        phrase6.run(phraseSequence)
        run(phraseWait) {
            GSAudio.sharedInstance.playSound (soundFileName: "talk4", loops: false, volume: 0.6)
        }

      
        backgroundSequence = SKAction.sequence([.wait(forDuration: 51), backgroundFadeIn,.wait(forDuration: 14), backgroundFadeOut])
        background5.run(backgroundSequence)


        phrase7.zPosition = 2
        phraseWait = SKAction.wait(forDuration: 52)
        phraseSequence = SKAction.sequence([.wait(forDuration: 52), fadeIn,.wait(forDuration: 5), fadeOut])
        phrase7.run(phraseSequence)
        run(phraseWait) {
            GSAudio.sharedInstance.playSound (soundFileName: "talk5", loops: false, volume: 0.6)
        }
        phraseWait = SKAction.wait(forDuration: 58)
        run(phraseWait){
            PlaygroundPage.current.navigateTo(page: .next)
//
        }
    }

}
