import AVFoundation

public class GSAudio: NSObject, AVAudioPlayerDelegate {

    public static let sharedInstance = GSAudio()

    private override init() {}

    var players = [NSURL:AVAudioPlayer]()
    var duplicatePlayers = [AVAudioPlayer]()

    public func playSound (soundFileName: String, loops: Bool = false, volume: Float = 0.3){

        let soundFileNameURL = NSURL(fileURLWithPath: Bundle.main.path(forResource: soundFileName, ofType: "mp3")!)

        if let player = players[soundFileNameURL] { //player for sound has been found

            if player.isPlaying == false { //player is not in use, so use that one
                player.numberOfLoops = loops ? -1 : 0
                player.volume = volume
                player.prepareToPlay()
                player.play()

            } else { // player is in use, create a new, duplicate, player and use that instead

                let duplicatePlayer = try! AVAudioPlayer(contentsOf: soundFileNameURL as URL)
                //use 'try!' because we know the URL worked before.

                duplicatePlayer.delegate = self
                //assign delegate for duplicatePlayer so delegate can remove the duplicate once it's stopped playing

                duplicatePlayers.append(duplicatePlayer)
                //add duplicate to array so it doesn't get removed from memory before finishing

                duplicatePlayer.prepareToPlay()
                duplicatePlayer.play()

            }
        } else { //player has not been found, create a new player with the URL if possible
            do{
                let player = try AVAudioPlayer(contentsOf: soundFileNameURL as URL)
                players[soundFileNameURL] = player
                player.numberOfLoops = loops ? -1 : 0
                player.prepareToPlay()
                player.volume = volume
                player.play()
            } catch {
                print("Could not play sound file!")
            }
        }
    }

    public func stopAll() {
      players.forEach { $0.1.stop() }
      duplicatePlayers.forEach { $0.stop() }
      players.removeAll()
      duplicatePlayers.removeAll()
    }
}
