import SpriteKit

public class GameScene2: SKScene{
    
    var phrase1Scene5: SKLabelNode!
    var phrase2Scene5: SKLabelNode!
    var filterM: SKSpriteNode!
    var lastBackground:SKSpriteNode!
    
    var mural: SKSpriteNode!
    
    public override func didMove(to view: SKView) {
        
        
        phrase1Scene5 = childNode(withName: "//phrase1Scene5") as? SKLabelNode
        phrase2Scene5 = childNode(withName: "//phrase2Scene5") as? SKLabelNode
        filterM = childNode(withName: "//filter") as? SKSpriteNode
        mural = childNode(withName: "//mural") as? SKSpriteNode
        lastBackground = childNode(withName: "//lastBackground") as? SKSpriteNode
        
        var phraseWait: SKAction!
        let fadeIn = SKAction.fadeIn(withDuration: 0.5)
        let fadeOut = SKAction.fadeOut(withDuration: 0.5)
       
        let backgroundFadeIn = SKAction.fadeIn(withDuration: 1)
        let backgroundFadeOut = SKAction.fadeOut(withDuration: 1)
        
        
        
        
//

        finalCollage.alpha = 1
        finalCollage.zPosition = 2
        finalCollage.position = CGPoint(x: -162, y: -25)
        finalCollage.setScale(0.5)
        addChild(finalCollage)
        
        var sequence = SKAction.sequence([backgroundFadeIn,.wait(forDuration: 11), backgroundFadeOut])
        mural.zPosition = 1
        mural.run(sequence)
        
        filterM.alpha = 0.5
        filterM.zPosition = 3
        filterM.run(sequence)


        phraseWait = SKAction.sequence([.wait(forDuration: 1.5)])
        sequence = SKAction.sequence([phraseWait,fadeIn,.wait(forDuration: 6.5), fadeOut])
        phrase1Scene5.zPosition = 4
        phrase1Scene5.run(sequence)
        run(phraseWait) {
            GSAudio.sharedInstance.playSound (soundFileName: "talk12", loops: false, volume: 0.5)
        }

        sequence = SKAction.sequence([.wait(forDuration: 12),backgroundFadeIn])
        lastBackground.zPosition = 4
        lastBackground.run(sequence)
        run(sequence){
            finalCollage.alpha = 0
        }

        phraseWait = SKAction.sequence([.wait(forDuration: 13)])
        sequence = SKAction.sequence([phraseWait,fadeIn,.wait(forDuration: 4)])
        phrase2Scene5.zPosition = 5
        phrase2Scene5.run(sequence)
        run(phraseWait) {
            GSAudio.sharedInstance.playSound (soundFileName: "talk13", loops: false, volume: 0.5)
        }
        
    }

    
}

