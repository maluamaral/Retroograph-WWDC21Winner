/*:
 # *Retroograph*
 
 *capture a photo of another photo!*
 
 This playgroundbook treats of a specific subject: our memories. They are everywhere and mark every piece of our life. In the same way the people we know and love also make us full of good and bad memories. However, sometimes these people leave our life and for the first time, we can begin to question the lack they leave us with. That's when we realize that the only thing left was the memories. It's painful, but I realized that I could do something to get past this, since other things can save these memories, photographs.
  
  In the world we live in they end up, the photographs becoming instantaneous. But they may have a very large value of feeling and belonging, especially the older ones, which are dusty and stored in some closet. It is them that mark our childhood, show our first friends, our relationship with the family and also the places we have been in the past. So the intention here is to revive them, it's to look again for them and maybe realize that today you have a very distinct vision of years ago. To look at them and can cry or laugh with situations that they portray and still deal with the weight of longing. It is to look at them and have the opportunity to resign it and make it a new photograph and remembrance. So, you know a little about me and my memories, but mostly they will join me to give it a new meaning!

 ---
 
 - Note: All photographs belong to me and were used to bring the melancholy and delicate sensation of our memories. Also, I ask for a for a better experience, activate the **sound** and hold in **full-screen**.
 
 *Enjoy the experience!*
 
 
 #### References Used:
 
 * [Emojipedia](https://emojipedia.org/apple/) : Emojis
 * [Freepick](https://br.freepik.com/vetores/mao) : cat
 * [Freepick](https://br.freepik.com/vetores/fundo) : leafs
 
 */

//#-hidden-code
//Um pouco de código escondido (só funciona no iPad)
import PlaygroundSupport
import SpriteKit
import UIKit
import BookCore

let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 1366, height: 1024))
if let scene = GameScene1(fileNamed: "GameScene") {
    scene.scaleMode = .aspectFill
    sceneView.presentScene(scene)
}

PlaygroundPage.current.liveView = sceneView
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.wantsFullScreenLiveView = true

//#-end-hidden-code


